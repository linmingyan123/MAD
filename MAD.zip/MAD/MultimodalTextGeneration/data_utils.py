# data_utils.py
import json, os
from torch.utils.data import Dataset
import xml.etree.ElementTree as ET
def get_dataset(mode, config):
    if config["task"] in ["fmnerg","gmner"]:
        return SentenceEntityDataset(
            text_file_path=config["text_dir"],
            img_file_path=config["image_dir"],
            mode=mode,
            data_format=config["data_format"],
    )
    else:
        raise NotImplementedError

class SentenceEntityDataset(Dataset):
    def __init__(self, text_file_path, img_file_path,
                 mode, data_format):
        self.img_file_path = img_file_path
        self.data = []

        # --- 加载原始数据 ---
        if data_format == "json":
            with open(os.path.join(text_file_path, mode + ".json"), "r", encoding="utf-8") as file:
                raw_data = json.load(file)
        else:
            raise ValueError("Unsupported data format. Currently only JSON is supported.")

        processed_data = []
        for ex in raw_data:
            image_id = str(ex.get("image_id", "")).strip()
            if not image_id:
                continue
            if not image_id.endswith(".npz"):
                image_id += ".npz"
            image_path = os.path.join(self.img_file_path, image_id)

            sentence = ex.get("sentence", "")
            if not isinstance(sentence, str):
                sentence = " ".join(map(str, sentence))
            sentence = sentence.strip()

            entities = ex.get("entities", [])
            if not isinstance(entities, list):
                entities = []

            processed_data.append({
                "image_path": image_path,
                "image_id": ex.get("image_id", ""),  # ✅ 保留原始 image_id
                "sentence": sentence,
                "entities": entities,
            })

        self.data = processed_data  # ✅ 替换掉原始 self.data



    def __len__(self):
        return len(self.data)

    def _read_image_label(self, img_id):
        # if not os.path.exists(
        #         os.path.join(self.image_annotation_path, img_id + ".xml")
        # ):
        #     return -1, -1, [], []
        # fn = os.path.join(self.image_annotation_path, img_id + ".xml")

        # tree = ET.parse(fn)
        root = tree.getroot()

        width = int(root.find("size/width").text)
        height = int(root.find("size/height").text)

        entities = []
        boxes = []

        for object_container in root.findall("object"):
            for names in object_container.findall("name"):
                box_name = names.text
                box_container = object_container.findall("bndbox")
                if len(box_container) > 0:
                    xmin = int(box_container[0].findall("xmin")[0].text)
                    ymin = int(box_container[0].findall("ymin")[0].text)
                    xmax = int(box_container[0].findall("xmax")[0].text)
                    ymax = int(box_container[0].findall("ymax")[0].text)
                    entities.append(box_name)
                    boxes.append([xmin, ymin, xmax, ymax])
        return width, height, entities, boxes

    def __getitem__(self, idx):
        sample = self.data[idx]
        return self.data[idx]
