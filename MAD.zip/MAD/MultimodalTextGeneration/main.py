import os
import sys
import gc
import datetime
import random
import json
import re
import types
from types import SimpleNamespace

os.environ["CUDA_VISIBLE_DEVICES"] = "6"

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader
from accelerate import Accelerator
from peft import LoraConfig, TaskType, get_peft_model
from peft.utils.other import prepare_model_for_kbit_training
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
)
from transformers.utils import logging as hf_logging
from tqdm import tqdm

from data_utils import get_dataset
from Trainer import Trainer


# =========================
# Utils
# =========================

def set_seed(seed: int):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

def load_pretrained_weights(model, ckpt_path):
    state_dict = torch.load(ckpt_path, map_location='cpu')

    def resize_param(param, target_shape):
        if param.shape == target_shape:
            return param
        print(f"⚠️ Resizing param from {param.shape} to {target_shape}")
        resized = torch.zeros(target_shape, dtype=param.dtype)
        num_to_copy = min(param.shape[0], target_shape[0])
        resized[:num_to_copy] = param[:num_to_copy]
        return resized

    for name in list(state_dict.keys()):
        if "embed_tokens.weight" in name or "shared.weight" in name or "lm_head.weight" in name:
            if name in model.state_dict():
                current_tensor = model.state_dict()[name]
                state_dict[name] = resize_param(state_dict[name], current_tensor.shape)

    model.load_state_dict(state_dict, strict=False)

def bf16_supported() -> bool:
    return torch.cuda.is_available() and torch.cuda.is_bf16_supported()

def get_default_dtype():
    return torch.bfloat16 if bf16_supported() else torch.float16

class Logger(object):
    """Redirect stdout/stderr to both console and a log file."""
    def __init__(self, filepath):
        self.terminal = sys.__stdout__
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        self.log = open(filepath, "w", encoding="utf-8")
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
    def flush(self):
        self.terminal.flush()
        self.log.flush()

class ProcessorShim:
    """Minimal shim so Trainer can access `.tokenizer`."""
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer


# =========================
# Collator (Qwen chat-style)
# =========================

class QwenChatCollator:
    def __init__(self, tokenizer, max_source_len=4096, max_target_len=1024,
                 label_pad_token_id=-100, min_target_tokens=1, keep_empty_strategy="skip"):
        self.tok = tokenizer
        self.max_source_len = max_source_len
        self.max_target_len = max_target_len
        self.label_pad_token_id = label_pad_token_id
        self.min_target_tokens = min_target_tokens
        self.keep_empty_strategy = keep_empty_strategy

    def _to_messages(self, ex):
        if "messages" in ex and isinstance(ex["messages"], list):
            return ex["messages"]

        src = (ex.get("instruction") or ex.get("input") or ex.get("question")
               or ex.get("prompt") or ex.get("src") or "")
        tgt = (ex.get("output") or ex.get("answer") or ex.get("response")
               or ex.get("tgt") or "")

        if ("sentence" in ex) and (isinstance(ex["sentence"], str)) and ex["sentence"].strip() != "":
            return [
                {"role": "user", "content": "请阅读并输出句子："},
                {"role": "assistant", "content": ex["sentence"].strip()},
            ]

        msgs = [{"role": "user", "content": str(src)}]
        if tgt is not None and str(tgt).strip() != "":
            msgs.append({"role": "assistant", "content": str(tgt)})
        return msgs

    def __call__(self, batch):
        import torch as _torch
        input_ids_list, labels_list, attn_masks = [], [], []
        kept = 0
        skipped_indices = []

        for bi, ex in enumerate(batch):
            messages = self._to_messages(ex)

            if len(messages) > 0 and messages[-1].get("role") == "assistant":
                prompt_msgs = messages[:-1]
                target_text = str(messages[-1].get("content", "") or "")

                prompt_text = self.tok.apply_chat_template(
                    prompt_msgs, tokenize=False, add_generation_prompt=True
                )
                full_text = prompt_text + target_text

                full_ids = self.tok(
                    full_text,
                    max_length=self.max_source_len + self.max_target_len,
                    truncation=True,
                    padding=False,
                )["input_ids"]

                prompt_ids = self.tok(
                    prompt_text,
                    max_length=self.max_source_len,
                    truncation=True,
                    padding=False,
                )["input_ids"]

                target_ids = full_ids[len(prompt_ids):]

                if len(target_ids) < self.min_target_tokens:
                    if self.keep_empty_strategy == "skip":
                        skipped_indices.append(bi)
                        continue
                    elif self.keep_empty_strategy == "all":
                        labels = [self.label_pad_token_id] * len(full_ids)
                    elif self.keep_empty_strategy == "train_all":
                        labels = full_ids[:]
                    else:
                        skipped_indices.append(bi)
                        continue
                else:
                    labels = [self.label_pad_token_id] * len(prompt_ids) + target_ids

                attn = [1] * len(full_ids)
                input_ids_list.append(_torch.tensor(full_ids, dtype=_torch.long))
                labels_list.append(_torch.tensor(labels, dtype=_torch.long))
                attn_masks.append(_torch.tensor(attn, dtype=_torch.long))
                kept += 1

            else:
                prompt_text = self.tok.apply_chat_template(
                    messages, tokenize=False, add_generation_prompt=True
                )
                full_ids = self.tok(
                    prompt_text,
                    max_length=self.max_source_len,
                    truncation=True,
                    padding=False,
                )["input_ids"]

                if self.keep_empty_strategy == "skip":
                    skipped_indices.append(bi)
                    continue
                elif self.keep_empty_strategy == "all":
                    labels = [self.label_pad_token_id] * len(full_ids)
                elif self.keep_empty_strategy == "train_all":
                    labels = full_ids[:]
                else:
                    skipped_indices.append(bi)
                    continue

                attn = [1] * len(full_ids)
                input_ids_list.append(_torch.tensor(full_ids, dtype=_torch.long))
                labels_list.append(_torch.tensor(labels, dtype=_torch.long))
                attn_masks.append(_torch.tensor(attn, dtype=_torch.long))
                kept += 1

        if kept == 0:
            raise ValueError(
                f"本批次无可训练样本（最后一条 assistant 为空或不存在）。已跳过索引: {skipped_indices[:10]}。"
            )

        max_len = max(x.size(0) for x in input_ids_list)
        pad_id = self.tok.pad_token_id
        bsz = len(input_ids_list)

        input_ids = _torch.full((bsz, max_len), pad_id, dtype=_torch.long)
        labels = _torch.full((bsz, max_len), self.label_pad_token_id, dtype=_torch.long)
        attention_mask = _torch.zeros((bsz, max_len), dtype=_torch.long)

        for i in range(bsz):
            L = input_ids_list[i].size(0)
            input_ids[i, :L] = input_ids_list[i]
            labels[i, :L] = labels_list[i]
            attention_mask[i, :L] = attn_masks[i]

        return {"input_ids": input_ids, "labels": labels, "attention_mask": attention_mask}


# =========================
# Model/Tokenizer helpers
# =========================

def _clean_cuda():
    try:
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
    except Exception:
        pass
    gc.collect()

def build_bnb_config(mode_4bit=True, compute_dtype=None):
    if compute_dtype is None:
        compute_dtype = get_default_dtype()
    if mode_4bit:
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=compute_dtype,
        )
    else:
        return BitsAndBytesConfig(load_in_8bit=True)

def safe_tokenizer(model_id):
    tok = AutoTokenizer.from_pretrained(
        model_id,
        use_fast=True,
        trust_remote_code=True
    )
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"
    return tok

def try_load_model(model_id, prefer_dtype=None, aggressive_offload=False, quant_mode: str = "none"):
    kwargs = dict(trust_remote_code=True)
    offload_folder = None
    if prefer_dtype is None:
        prefer_dtype = get_default_dtype()
    if aggressive_offload:
        offload_folder = os.path.abspath("./offload_dir")
        os.makedirs(offload_folder, exist_ok=True)

    if quant_mode == "4bit":
        quant_cfg = build_bnb_config(mode_4bit=True, compute_dtype=prefer_dtype)
        return AutoModelForCausalLM.from_pretrained(
            model_id, quantization_config=quant_cfg,
            device_map="auto", offload_folder=offload_folder, **kwargs
        )
    if quant_mode == "8bit":
        quant_cfg = build_bnb_config(mode_4bit=False)
        return AutoModelForCausalLM.from_pretrained(
            model_id, quantization_config=quant_cfg,
            device_map="auto", offload_folder=offload_folder, **kwargs
        )

    if torch.cuda.is_available():
        return AutoModelForCausalLM.from_pretrained(
            model_id, torch_dtype=prefer_dtype,
            device_map="auto", offload_folder=offload_folder, **kwargs
        )
    else:
        return AutoModelForCausalLM.from_pretrained(
            model_id, torch_dtype=prefer_dtype, device_map="cpu", **kwargs
        )

def load_causal_lm_with_fallbacks(model_id, use_qlora: bool):
    prefer_dtype = get_default_dtype()
    try:
        return try_load_model(model_id, prefer_dtype, aggressive_offload=False, quant_mode="none")
    except torch.cuda.OutOfMemoryError as e:
        print("[Load 1] OOM:", repr(e)); _clean_cuda()
    except Exception as e:
        print("[Load 1] Failed:", repr(e)); _clean_cuda()

    if use_qlora:
        try:
            print("[Load 2] 4bit nf4 + auto")
            return try_load_model(model_id, prefer_dtype, aggressive_offload=False, quant_mode="4bit")
        except Exception as e:
            print("[Load 2] Failed:", repr(e)); _clean_cuda()

    try:
        print("[Load 3] 8bit + auto")
        return try_load_model(model_id, prefer_dtype, aggressive_offload=False, quant_mode="8bit")
    except Exception as e:
        print("[Load 3] Failed:", repr(e)); _clean_cuda()

    try:
        print("[Load 4] dtype + auto + offload_folder")
        return try_load_model(model_id, prefer_dtype, aggressive_offload=True, quant_mode="none")
    except Exception as e:
        print("[Load 4] Failed:", repr(e)); _clean_cuda()
        raise RuntimeError("All loading strategies failed.") from e

def align_tokenizer_and_heads(model, tokenizer):
    tok_len = len(tokenizer)
    emb = model.get_input_embeddings()
    base_vocab = emb.weight.shape[0]
    cfg_vocab = int(getattr(model.config, "vocab_size", 0)) or base_vocab
    target_vocab = max(tok_len, base_vocab, cfg_vocab)

    if tok_len < target_vocab:
        extra = target_vocab - tok_len
        tokenizer.add_tokens([f"<extra_tok_{i}>" for i in range(extra)], special_tokens=False)

    model.resize_token_embeddings(len(tokenizer), pad_to_multiple_of=64)

    emb = model.get_input_embeddings()
    new_vocab = emb.weight.shape[0]
    model.config.vocab_size = new_vocab

    lm_head = getattr(model, "lm_head", None)
    if lm_head is None or lm_head.weight.shape[0] != new_vocab:
        hidden = getattr(model.config, "hidden_size", emb.weight.shape[1])
        new_head = torch.nn.Linear(hidden, new_vocab, bias=False, device=emb.weight.device, dtype=emb.weight.dtype)
        with torch.no_grad():
            if lm_head is not None:
                copy_rows = min(lm_head.weight.shape[0], new_vocab)
                new_head.weight[:copy_rows].copy_(lm_head.weight[:copy_rows].to(emb.weight.device))
                if new_vocab > lm_head.weight.shape[0]:
                    torch.nn.init.normal_(
                        new_head.weight[copy_rows:],
                        mean=0.0,
                        std=getattr(model.config, "initializer_range", 0.02),
                    )
            else:
                torch.nn.init.normal_(
                    new_head.weight,
                    mean=0.0,
                    std=getattr(model.config, "initializer_range", 0.02),
                )
        model.lm_head = new_head

def unify_pad_token_ids(tokenizer, model, prefer_id=None):
    pid = prefer_id
    if pid is None:
        pid = getattr(model.config, "pad_token_id", None) or tokenizer.pad_token_id
    tokenizer.pad_token_id = pid
    model.config.pad_token_id = pid
    if hasattr(model, "generation_config") and model.generation_config is not None:
        model.generation_config.pad_token_id = tokenizer.pad_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    return pid


# =========================
# Training entry
# =========================

def main():
    # -------- Load config --------
    with open("/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/config.yaml", "r") as yaml_file:
        config = yaml.safe_load(yaml_file)
        config["text_dir"] = os.path.join(config["text_dir"], config["dataset"])
        config["training_argument"]["output_dir"] = os.path.join(
            config["training_argument"]["output_dir"], config["dataset"]
        )

    # -------- Logging --------
    hf_logging.set_verbosity_info()
    accelerator = Accelerator()

    set_seed(config["seed"])

    output_dir = config["training_argument"]["output_dir"]
    os.makedirs(output_dir, exist_ok=True)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_path = os.path.join(output_dir, f"{current_time}.log")
    sys.stdout = Logger(log_path)
    sys.stderr = sys.stdout
    print(f"🔍 所有输出重定向到: {log_path}")

    # -------- Model & Tokenizer --------
    model_id = config.get("model_name_or_path")
    if not model_id:
        raise ValueError("config.yaml 缺少必填字段 `model_name_or_path`。")
    use_qlora = bool(config.get("use_qlora", False))

    tokenizer = safe_tokenizer(model_id)
    processor = ProcessorShim(tokenizer)

    train_dataset = get_dataset("train", config)
    test_dataset = get_dataset("test", config)
    dev_dataset = get_dataset("dev", config)
    print(f"[Data] train size = {len(train_dataset)} / dev size = {len(dev_dataset)}")
    try:
        print("[Data] train[0] keys:", list(train_dataset[0].keys()))
        print("[Data] dev[0] keys:", list(dev_dataset[0].keys()))
    except Exception as e:
        print("[Data] sample access failed:", e)

    collator = QwenChatCollator(
        tokenizer,
        max_source_len=2048,
        max_target_len=1024,
        label_pad_token_id=-100,
        min_target_tokens=8,
        keep_empty_strategy="skip",
    )

    if config["run_mode"] == "do_train":
        model = load_causal_lm_with_fallbacks(model_id, use_qlora)

        # ---- Tokenizer/Model 对齐与 pad 统一 ----
        align_tokenizer_and_heads(model, tokenizer)
        prefer_pad = getattr(model.config, "pad_token_id", None) or tokenizer.pad_token_id
        if prefer_pad in (None, 0):
            prefer_pad = 151654
        unify_pad_token_ids(tokenizer, model, prefer_id=prefer_pad)
        model.config.use_cache = False

        # ---- LoRA/QLoRA 可选启用 ----
        is_lora = str(config.get("trainable_mode", "")).lower() == "lora"
        if is_lora:
            peft_cfg_from_yaml = config.get("peft", {}) or {}
            if use_qlora:
                model = prepare_model_for_kbit_training(model)
            peft_config = LoraConfig(
                inference_mode=False,
                r=int(peft_cfg_from_yaml.get("r", 8)),
                lora_alpha=int(peft_cfg_from_yaml.get("lora_alpha", 32)),
                lora_dropout=float(peft_cfg_from_yaml.get("lora_dropout", 0.1)),
                target_modules=peft_cfg_from_yaml.get(
                    "target_modules",
                    ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
                ),
                task_type=TaskType.CAUSAL_LM,
            )
            model = get_peft_model(model, peft_config)
            try:
                model.print_trainable_parameters()
            except Exception:
                pass

        # ---- DataLoader ----
        train_loader = DataLoader(
            train_dataset,
            batch_size=int(config["training_argument"]["train_batch_size"]),
            shuffle=True,
            collate_fn=collator,
            num_workers=int(config["training_argument"].get("dataloader_num_workers", 0)),
        )
        val_loader = DataLoader(
            dev_dataset,
            batch_size=int(config["training_argument"]["eval_batch_size"]),
            shuffle=False,
            collate_fn=collator,
            num_workers=int(config["training_argument"].get("dataloader_num_workers", 0)),
        )

        # ---- Accelerator 包装（模型 + dataloader）----
        model, train_loader, val_loader = accelerator.prepare(model, train_loader, val_loader)

        # ---- Trainer 构建 ----
        criterion = torch.nn.CrossEntropyLoss(ignore_index=-100)
        args = SimpleNamespace(
            lr=float(config["training_argument"].get("learning_rate", 1e-5)),
            weight_decay=float(config["training_argument"].get("weight_decay", 0.01)),
            grad_clip=float(config["training_argument"].get("max_grad_norm", 1.0)),
            task=config.get("task", ""),
            ignore_index=-100,
            use_dummy_loss=False,
            gradient_accumulation_steps=int(config["training_argument"].get("gradient_accumulation_steps", 1) or 1),
        )

        trainer = Trainer(
            model=model,
            criterion=criterion,
            args=args,
            processor=processor,
            data_collator=collator,
            train_dataset=train_dataset,
            eval_dataset=dev_dataset,
            test_dataset=test_dataset,
            train_dataloader=train_loader,
            eval_dataloader=val_loader,
            **config["training_argument"],
        )

        # =========================
        # Monkey-patch: 如果 Trainer 没有 train_one_epoch/evaluate，就在 main.py 里补齐
        # （保证 do_train 原逻辑不变）
        # =========================
        if not hasattr(trainer, "train_one_epoch") or not hasattr(trainer, "evaluate"):
            print("⚠️ Trainer 缺少 train_one_epoch/evaluate，main.py 将在运行时补齐以继续微调 + 保存最优权重。")

            def _train_one_epoch(self, loader, epoch: int):
                self.model.train()
                total_loss = 0.0
                n_steps = 0

                grad_accum = int(getattr(self.args, "gradient_accumulation_steps", 1) or 1)
                grad_clip = float(getattr(self.args, "grad_clip", 1.0) or 1.0)

                self.optimizer.zero_grad(set_to_none=True)

                pbar = tqdm(loader, desc=f"Train(ep={epoch})", dynamic_ncols=True)
                for step, batch in enumerate(pbar, start=1):
                    with accelerator.autocast():
                        outputs = self.model(**batch)
                        loss = outputs.loss
                        loss = loss / grad_accum

                    accelerator.backward(loss)

                    if step % grad_accum == 0:
                        try:
                            accelerator.clip_grad_norm_(self.model.parameters(), grad_clip)
                        except Exception:
                            pass
                        self.optimizer.step()
                        self.optimizer.zero_grad(set_to_none=True)

                    total_loss += float(loss.detach().item()) * grad_accum
                    n_steps += 1
                    pbar.set_postfix(loss=total_loss / max(1, n_steps))

                return total_loss / max(1, n_steps)

            @torch.no_grad()
            def _evaluate(self, loader):
                self.model.eval()
                total_loss = 0.0
                n_steps = 0

                pbar = tqdm(loader, desc="Eval", dynamic_ncols=True)
                for batch in pbar:
                    with accelerator.autocast():
                        outputs = self.model(**batch)
                        loss = outputs.loss
                    total_loss += float(loss.detach().item())
                    n_steps += 1
                    pbar.set_postfix(loss=total_loss / max(1, n_steps))

                return total_loss / max(1, n_steps)

            trainer.train_one_epoch = types.MethodType(_train_one_epoch, trainer)
            trainer.evaluate = types.MethodType(_evaluate, trainer)

        # ---- 可选：从断点恢复 adapter/整模 ----
        resume_dir = config.get("resume_from", None)
        if isinstance(resume_dir, str) and os.path.isdir(resume_dir):
            try:
                print(f"[Resume] 从 {resume_dir} 恢复权重")
                unwrapped = accelerator.unwrap_model(trainer.model)
                if is_lora and hasattr(unwrapped, "load_adapter"):
                    unwrapped.load_adapter(resume_dir)
                else:
                    base_unwrapped = accelerator.unwrap_model(model)
                    base_unwrapped.from_pretrained(resume_dir)
            except Exception as e:
                print(f"[Resume] 失败（忽略继续）: {e}")

        # ---- 训练 & 选择最优并保存 ----
        num_epochs = int(config.get("training_argument", {}).get("num_train_epochs", 3))
        best_val = float("inf")
        best_dir = os.path.join(output_dir, "best")
        os.makedirs(best_dir, exist_ok=True)

        for ep in range(1, num_epochs + 1):
            print(f"\n===== Epoch {ep}/{num_epochs} =====")
            train_loss = trainer.train_one_epoch(train_loader, ep)
            val_loss = trainer.evaluate(val_loader)
            print(f"[Epoch {ep}] train_loss={train_loss:.6f}  val_loss={val_loss:.6f}")

            if val_loss < best_val:
                best_val = val_loss
                to_save = accelerator.unwrap_model(trainer.model)
                try:
                    # 覆盖式保存
                    for f in os.listdir(best_dir):
                        p = os.path.join(best_dir, f)
                        try:
                            if os.path.isdir(p):
                                import shutil
                                shutil.rmtree(p)
                            else:
                                os.remove(p)
                        except Exception:
                            pass

                    to_save.save_pretrained(best_dir, safe_serialization=True)
                    tokenizer.save_pretrained(best_dir)
                    print(f"[Best] 更新最优 (val_loss={best_val:.6f}) → {best_dir}")
                except Exception as e:
                    print(f"[Best] 保存失败（忽略）: {e}")

        print(f"[Train Done] 最优验证损失: {best_val:.6f}，保存目录：{best_dir}")
        return

    elif config["run_mode"] == "do_inference":
        model = load_causal_lm_with_fallbacks(model_id, use_qlora)

        if str(config.get("trainable_mode", "")).lower() == "lora":
            peft_cfg_from_yaml = config.get("peft", {}) or {}
            peft_config = LoraConfig(
                inference_mode=False,
                r=int(peft_cfg_from_yaml.get("r", 8)),
                lora_alpha=int(peft_cfg_from_yaml.get("lora_alpha", 32)),
                lora_dropout=float(peft_cfg_from_yaml.get("lora_dropout", 0.1)),
                target_modules=peft_cfg_from_yaml.get(
                    "target_modules",
                    ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
                ),
            )
            if use_qlora:
                model = get_peft_model(model, peft_config)
                # 如需加载 checkpoint，请用 load_pretrained_weights

        criterion = torch.nn.CrossEntropyLoss(ignore_index=-100)
        args = SimpleNamespace(
            lr=1e-5,
            weight_decay=0.01,
            grad_clip=1.0,
            task=config.get("task", ""),
            ignore_index=-100,
            use_dummy_loss=False,
        )

        trainer = Trainer(
            model=model,
            criterion=criterion,
            args=args,
            processor=processor,
            data_collator=collator,
            train_dataset=train_dataset,
            test_dataset=test_dataset,
            eval_dataset=dev_dataset,
            **config["training_argument"],
        )

        dataset_name = config.get("dataset", "medical")
        trainer.aug_data_generate(dataset=dataset_name, num_return_sequences=int(config.get("num_return_sequences", 5)))
        trainer.convert_txt_to_bio_and_json(
            txt_path=f"/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/augmented/txt_raw_sentence/{dataset_name}/aug_sentence.txt",
            orig_bio_path=f"/home/wurenji/projects/Linlinlin/MAD/dataset/{dataset_name}/txt/train.txt",
            out_json_path=f"/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/augmented/{dataset_name}_train.json",
            out_bio_path=f"/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/augmented/{dataset_name}_train.txt"
        )
        print("✅ do_inference 完成。")
        return

    else:
        raise ValueError(f"未知 run_mode: {config['run_mode']}（期望 do_train / do_inference）")


if __name__ == "__main__":
    main()
