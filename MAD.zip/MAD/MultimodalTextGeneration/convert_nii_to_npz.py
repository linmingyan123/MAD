import os
import numpy as np
import nibabel as nib
from tqdm import tqdm

def convert_nii_to_npz(input_dir, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    nii_files = [f for f in os.listdir(input_dir) if f.endswith(".nii") or f.endswith(".nii.gz")]

    print(f"📦 共找到 {len(nii_files)} 个 NIfTI 文件，开始转换...")

    for filename in tqdm(nii_files, desc="转换进度"):
        try:
            nii_path = os.path.join(input_dir, filename)
            npz_name = os.path.splitext(os.path.splitext(filename)[0])[0] + ".npz"  # 去掉.gz

            # 加载 NIfTI 数据
            nii_img = nib.load(nii_path)
            data = nii_img.get_fdata()

            # 取中间切片
            slice_index = data.shape[2] // 2
            slice_2d = data[:, :, slice_index]

            # 归一化
            norm_slice = (slice_2d - np.min(slice_2d)) / (np.max(slice_2d) - np.min(slice_2d) + 1e-5)
            norm_slice = norm_slice.astype(np.float32)

            # 保存为 .npz
            output_path = os.path.join(output_dir, npz_name)
            np.savez_compressed(output_path, image=norm_slice)

        except Exception as e:
            print(f"❌ 错误处理文件 {filename}: {e}")

    print("✅ 所有转换完成！")

if __name__ == "__main__":
    # 请修改为你的路径
    input_dir = "/home/wurenji/projects/Linlinlin/GMDA/CT-RATE/1/"
    output_dir = "/home/wurenji/projects/Linlinlin/GMDA/CT-RATE/mn"

    convert_nii_to_npz(input_dir, output_dir)
