# -*- coding: utf-8 -*-
"""
替换版：数据处理 + 冲突检测（drop-in）
================================================
在不改变原有对外行为/目录结构/函数签名的前提下，增加了以下安全检查与告警：

1) 数量对齐检测（严格）
   - main(): 检查增强文本非空行数 是否等于 len(raw_json)*sample_number，不相等则直接抛错并给出详细提示。

2) 有标签增强（keep_all 路径）的软校验（仅告警，不过滤）
   - 对每条增强样本检查：
     a) 句长过短(<5)或过长(>=30)
     b) 实体 tag 非法/重复/空文本/含 '-' 等
   - 均打印 [WARN]，但仍保留（保持 keep_all 语义不变）。
   - 若需要严格过滤，请继续使用 process_labeled_file_gmner（本函数仍保留了“严格版”逻辑）。

3) JSON -> TXT 的实体对齐改为大小写不敏感匹配，并支持多处出现
   - 若某个实体在 tokens 中完全匹配失败，打印 [WARN]，避免“静默漏标”。
   - 仍然输出原格式，不改变训练方接口。

4) 无标签增强路径（check_and_turn_to_json）
   - 增加边界保护与越界风险提示；保留既有断言（保持强一致性）。

5) 统计与汇总
   - 在 JSON->TXT 转换后打印 unmatched 实体计数
   - 在 keep_all/path 打印软校验告警计数

如需将“告警”提升为“硬错误”，可将 warn(...) 改为 raise ValueError(...)
"""

import json
import os
import re
import yaml

from data_utils import get_dataset
from remove_label_in_raw_sentence import process_sentence, extract_entities

# =========================
# 常量/配置
# =========================
ALLOWED_TAGS = {"organ", "disease", "process", "tissue", "other"}

coarse_fine_tree = {
    "organ": ["右肺", "肺", "肺门", "冠状动脉", "胸", "基底节区", "胸廓", "支气管", "纵隔", "肺动脉", "冠状动脉", "心", "心脏", "舌", "左肺"],
    "tissue": ["肺纹理", "结节", "小结节", "淋巴结", "胸壁", "软组织"],
    "disease": ["双肺炎症", "肺炎", "右侧胸腔积液", "主动脉及冠状动脉硬化", "肺动脉高压", "慢支", "肺气肿", "主动脉硬化", "两肺小结节", "脂肪肝", "肺间质纤维化"],
    "process": ["感染", "膨胀不全", "炎性病变", "胆囊切除术后", "右侧乳腺癌保乳术后", "陈旧性病变"],
    "other": ["片状密度增高影", "食管平滑肌瘤术后", "高密度结节影", "颅内血肿清除术", "去颅骨骨瓣减压术"],
}

# =========================
# 规范化与去重
# =========================
def norm_text(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip().lower()


def dedup_aug_list(items):
    """
    通用去重：基于 (image_id, 规范化后的 sentence) 去重。
    items: List[{"image_id":..., "sentence":..., ...}]
    """
    seen = set()
    dedup = []
    for d in items:
        key = (d.get("image_id", ""), norm_text(d.get("sentence", "")))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(d)
    return dedup


# =========================
# 工具函数：匹配/替换/分词预处理
# =========================
def is_match_case_insensitive(string, match):
    pattern = re.compile(re.escape(match), re.IGNORECASE)
    match_found = pattern.search(string)
    return bool(match_found)


def replace_case_insensitive(string, span):
    pattern = re.compile(re.escape(span), re.IGNORECASE)
    result = pattern.sub(span, string)
    return result


def add_space_between_symbols_and_letters(text):
    """
    在非字母/数字/下划线的符号与其相邻的字母数字之间插入一个空格，帮助分词稳定。
    """
    pattern = re.compile(r"(?<=[^\w\s])\s*|\s*(?=[^\w\s])")
    spaced_text = re.sub(pattern, " ", text)
    return spaced_text


# =========================
# 额外：实体 token 级匹配（大小写不敏感，支持多处）
# =========================
def _find_entity_spans_case_insensitive(tokens, entity_tokens):
    lt = [t.lower() for t in tokens]
    le = [t.lower() for t in entity_tokens]
    spans = []
    i = 0
    L, E = len(lt), len(le)
    if E == 0 or L == 0 or E > L:
        return spans
    while i <= L - E:
        if lt[i:i+E] == le:
            spans.append((i, i+E))  # 左闭右开
            i += E
        else:
            i += 1
    return spans


# =========================
# 评估/统计（原样保留）
# =========================
def check():
    with open("config.yaml", "r") as yaml_file:
        config = yaml.safe_load(yaml_file)

    check_txt = "/home/wurenji/projects/Linlinlin/GMDA/MultimodalTextGeneration/output_dir/CT-RATE-zh/lora/aug_text/CT-RATE-zh_aug_text_train-0.0002_epochs-30.txt"

    config["dataset"] = "CT-RATE-zh"
    config["text_dir"] = os.path.join(config["text_dir"], config["dataset"])
    config["training_argument"]["output_dir"] = os.path.join(
        config["training_argument"]["output_dir"], config["dataset"]
    )

    test_dataset = get_dataset("train", config)

    with open(check_txt, "r", encoding="utf-8") as f:
        raw_lines = [line.strip() for line in f]

    unique_norm_lines = []
    seen_norm = set()
    for line in raw_lines:
        n = norm_text(line)
        if n and n not in seen_norm:
            seen_norm.add(n)
            unique_norm_lines.append(line)

    aug_text = unique_norm_lines

    aug_json_list = []
    useful_seen = set()
    useful_items = 0
    sum_items = 0

    for test_data, aug_text_item in zip(test_dataset, aug_text):
        if not aug_text_item:
            continue
        sum_items += 1

        entities_appear = True
        for entity in test_data["entities"]:
            if entity["text"] not in aug_text_item:
                entities_appear = False
                break

        if entities_appear:
            key = (test_data["image_id"], norm_text(aug_text_item))
            if key not in useful_seen:
                useful_seen.add(key)
                aug_json = {
                    "image_id": test_data["image_id"],
                    "entities": test_data["entities"],
                    "sentence": aug_text_item,
                }
                aug_json_list.append(aug_json)
                useful_items += 1

    print(
        f"{check_txt}\n"
        f"useful aug num (去重后): {useful_items} || sum aug num (去重后): {sum_items} || "
        f"Proportion: {useful_items * 100.0 / max(1, sum_items):.2f}%"
    )


# =========================
# JSON ⇄ TXT 转换（加入匹配告警）
# =========================
def json_to_txt_fmnerg(json_data, output_file, aug=False):
    unmatched_entity_total = 0
    with open(output_file, "w", encoding="utf-8") as txt_file:
        for entry in json_data:
            image_id = entry["image_id"]
            sentence = add_space_between_symbols_and_letters(entry["sentence"])
            if len(sentence) == 0:
                continue
            entities = entry.get("entities", [])

            if aug is False:
                txt_file.write(f"IMGID:{image_id}\n")
            else:
                txt_file.write(f"IMGID:{image_id}_aug\n")

            if sentence:
                tokens = sentence.split()
                coarse_tags = ["O" for _ in range(len(tokens))]
                fine_tags = ["O" for _ in range(len(tokens))]
                for entity in entities:
                    text = entity["text"]
                    entity_tokens = text.split()
                    spans = _find_entity_spans_case_insensitive(tokens, entity_tokens)
                    if not spans:
                        unmatched_entity_total += 1
                    for (b, e) in spans:
                        coarse = entity.get("tag_coarse", "O")
                        fine = entity.get("tag_fine", "O")
                        coarse_tags[b] = f'B-{coarse}'
                        fine_tags[b] = f'B-{fine}'
                        for j in range(b + 1, e):
                            coarse_tags[j] = f'I-{coarse}'
                            fine_tags[j] = f'I-{fine}'

                for i, token in enumerate(tokens):
                    txt_file.write(f"{token}\t{coarse_tags[i]}\t{fine_tags[i]}\n")

            txt_file.write("\n")

    if unmatched_entity_total > 0:
        print(f"[WARN] FMNERG: {unmatched_entity_total} 实体在 JSON->TXT 时未能对齐到 tokens（大小写不敏感匹配失败）。")


def json_to_txt_gmner(json_data, output_file, aug=False):
    unmatched_entity_total = 0
    with open(output_file, "w", encoding="utf-8") as txt_file:
        for entry in json_data:
            image_id = entry["image_id"]
            sentence = add_space_between_symbols_and_letters(entry["sentence"])
            if len(sentence) == 0:
                continue
            entities = entry.get("entities", [])
            if aug is False:
                txt_file.write(f"IMGID:{image_id}\n")
            else:
                txt_file.write(f"IMGID:{image_id}_aug\n")

            if sentence:
                tokens = sentence.split()
                tags = ["O" for _ in range(len(tokens))]
                for entity in entities:
                    text = entity["text"]
                    entity_tokens = text.split()
                    spans = _find_entity_spans_case_insensitive(tokens, entity_tokens)
                    if not spans:
                        unmatched_entity_total += 1
                    for (b, e) in spans:
                        tag = entity.get("tag", "O")
                        tags[b] = f'B-{tag}'
                        for j in range(b + 1, e):
                            tags[j] = f'I-{tag}'

                for i, token in enumerate(tokens):
                    txt_file.write(f"{token}\t{tags[i]}\n")

            txt_file.write("\n")

    if unmatched_entity_total > 0:
        print(f"[WARN] GMNER: {unmatched_entity_total} 实体在 JSON->TXT 时未能对齐到 tokens（大小写不敏感匹配失败）。")


# =========================
# 生成文本 → JSON（加入去重/软校验/边界保护）
# =========================
def _soft_validate_entities_gmner(entities):
    """
    keep_all 路径的软校验：仅返回 (is_ok, warn_msgs)，不做过滤。
    """
    warn_msgs = []
    seen_text = set()
    for ent in entities:
        tag = ent.get("tag", "")
        text = ent.get("text", "")
        if tag not in ALLOWED_TAGS:
            warn_msgs.append(f"非法tag:{tag}")
        if not text:
            warn_msgs.append("空实体文本")
        if "-" in text:
            warn_msgs.append(f"实体含'-':{text}")
        if text in seen_text:
            warn_msgs.append(f"重复实体文本:{text}")
        seen_text.add(text)
    return (len(warn_msgs) == 0, warn_msgs)


def check_and_turn_to_json(aug_txt_lines, raw_json_data, sample_number=1):
    img_ids = [item["image_id"] for item in raw_json_data]
    aug_text_list_with_img_ids = []
    index = 0

    # 分组前先裁剪到最大期望条数，避免 index 越界
    non_empty_aug = [t.strip() for t in aug_txt_lines if t.strip()]
    expected_total = len(img_ids) * sample_number
    if len(non_empty_aug) > expected_total:
        print(f"[WARN] 无标签路径: 增强文本非空行({len(non_empty_aug)}) > 期望({expected_total})，已自动截断到期望条数。")
        non_empty_aug = non_empty_aug[:expected_total]

    for text in non_empty_aug:
        if len(aug_text_list_with_img_ids) == 0 or len(aug_text_list_with_img_ids[-1]["text"]) == sample_number:
            aug_text_list_with_img_ids.append({"image_id": img_ids[index], "text": []})
            index += 1
        aug_text_list_with_img_ids[-1]["text"].append(text)

    aug_json_out_list = []
    kept_image_ids = set()

    for dict_item, raw_json_item in zip(aug_text_list_with_img_ids, raw_json_data):
        assert dict_item["image_id"] == raw_json_item["image_id"]
        entities = raw_json_item["entities"]
        kept_this_image = False

        for text in dict_item["text"]:
            augmented_entities = []

            if len(text.split()) < 5:
                continue

            do_have_entities = False
            for entity in entities:
                if is_match_case_insensitive(text, entity["text"]):
                    text = replace_case_insensitive(text, entity["text"])
                    do_have_entities = True
                    augmented_entities.append(entity)

            if do_have_entities is False and len(entities) > 0:
                continue

            kept_this_image = True
            aug_json_out_list.append(
                {
                    "image_id": raw_json_item["image_id"],
                    "entities": augmented_entities,
                    "sentence": text,
                }
            )

        if kept_this_image:
            kept_image_ids.add(raw_json_item["image_id"])

    dedup_list = dedup_aug_list(aug_json_out_list)

    total_text_candidates = len(img_ids) * sample_number
    percentage_useful_images = len(kept_image_ids) / max(1, len(img_ids)) * 100

    print(
        f"All Text (候选总数): {total_text_candidates}\n"
        f"Total Remain Useful ImageIDs (至少保留一条) : {len(kept_image_ids)}/{len(img_ids)} || {percentage_useful_images:.2f}%\n"
        f"样本条数（去重前/后）: {len(aug_json_out_list)} / {len(dedup_list)}"
    )

    return dedup_list


def process_labeled_file_gmner_keep_all(aug_txt_lines, raw_json_data, sample_number=1):
    """
    保持 keep_all 语义：不主动过滤，但对可疑样本发出 [WARN]。
    """
    img_ids = [item["image_id"] for item in raw_json_data]
    img_ids_with_sample_number_repeat = [item for item in img_ids for _ in range(sample_number)]
    aug_txt_lines_sample_number_samples = [item for item in aug_txt_lines if len(item.strip()) > 0]

    # 数量裁剪到期望上限（同时保留警告）
    expected_total = len(img_ids) * sample_number
    if len(aug_txt_lines_sample_number_samples) > expected_total:
        print(f"[WARN] keep_all: 增强文本非空行({len(aug_txt_lines_sample_number_samples)}) > 期望({expected_total})，已自动截断到期望条数。")
        aug_txt_lines_sample_number_samples = aug_txt_lines_sample_number_samples[:expected_total]

    aug_text_list_with_img_ids = []
    warn_counter = 0

    for (text, image_id) in zip(aug_txt_lines_sample_number_samples, img_ids_with_sample_number_repeat):
        aug_text_dict = process_sentence(text, task="gmner")  # sentence + entities(tag,text)
        # 软校验（仅 warn 不过滤）
        if len(aug_text_dict.get("sentence", "").split(" ")) < 5:
            print(f"[WARN] keep_all: 句长过短(<5)，image_id={image_id}")
            warn_counter += 1
        if len(aug_text_dict.get("sentence", "").split(" ")) >= 30:
            print(f"[WARN] keep_all: 句长过长(>=30)，image_id={image_id}")
            warn_counter += 1
        ok, msgs = _soft_validate_entities_gmner(aug_text_dict.get("entities", []))
        if not ok:
            print(f"[WARN] keep_all: 实体可疑(image_id={image_id}) -> {', '.join(msgs)}")
            warn_counter += 1

        aug_text_dict["image_id"] = image_id
        aug_text_list_with_img_ids.append(aug_text_dict)

    dedup_list = dedup_aug_list(aug_text_list_with_img_ids)
    print(f"keep_all: 原条数 {len(aug_text_list_with_img_ids)} | 去重后 {len(dedup_list)} | WARN 次数 {warn_counter}")
    return dedup_list


def process_labeled_file_gmner(aug_txt_lines, raw_json_data, sample_number=1):
    """
    严格版：不合规直接丢弃（原逻辑保留）。
    """
    unavailable_entity_count = 0

    img_ids = [item["image_id"] for item in raw_json_data]
    img_ids_with_sample_number_repeat = [item for item in img_ids for _ in range(sample_number)]
    aug_txt_lines_sample_number_samples = [item for item in aug_txt_lines if len(item.strip()) > 0]
    aug_text_list_with_img_ids = []
    total_number = len(aug_txt_lines_sample_number_samples)

    expected_total = len(img_ids) * sample_number
    if len(aug_txt_lines_sample_number_samples) > expected_total:
        print(f"[WARN] 严格版: 增强文本非空行({len(aug_txt_lines_sample_number_samples)}) > 期望({expected_total})，已自动截断到期望条数。")
        aug_txt_lines_sample_number_samples = aug_txt_lines_sample_number_samples[:expected_total]

    for (text, image_id) in zip(aug_txt_lines_sample_number_samples, img_ids_with_sample_number_repeat):
        aug_text_dict = process_sentence(text, task="gmner")

        if len(aug_text_dict["sentence"].split(" ")) < 5:
            continue
        if len(aug_text_dict["sentence"].split(" ")) >= 30:
            continue
        is_available = True
        entity_text_list = []
        for entity in aug_text_dict["entities"]:
            if (
                entity.get("tag") not in ALLOWED_TAGS
                or entity.get("text") in entity_text_list
                or len(entity.get("text", "")) == 0
                or "-" in entity.get("text", "")
            ):
                is_available = False
            entity_text_list.append(entity.get("text"))

        if not is_available:
            unavailable_entity_count += 1
            continue

        aug_text_dict["image_id"] = image_id
        aug_text_list_with_img_ids.append(aug_text_dict)

    dedup_list = dedup_aug_list(aug_text_list_with_img_ids)

    print(f"unavailable_entity_count : {unavailable_entity_count}")
    print(f"count useful items : {len(dedup_list)} (去重后) / 原始候选 {total_number}")

    return dedup_list


# =========================
# BIO 标签 → span
# =========================
def _bio_tag_to_spans(tags, ignore_labels=None):
    """
    给定一个tags的list，比如['O', 'B-singer', 'I-singer', 'I-singer', 'O', 'O']。
    返回[('singer', (1, 4))] (左闭右开区间)
    """
    ignore_labels = set(ignore_labels) if ignore_labels else set()

    spans = []
    prev_bio_tag = None
    for idx, tag in enumerate(tags):
        tag = tag.lower()
        bio_tag, label = tag[:1], tag[2:]
        if bio_tag == "b":
            spans.append((label, [idx, idx]))
        elif bio_tag == "i" and prev_bio_tag in ("b", "i") and spans and label == spans[-1][0]:
            spans[-1][1][1] = idx
        elif bio_tag == "o":
            pass
        else:
            spans.append((label, [idx, idx]))
        prev_bio_tag = bio_tag
    return [(span[0], (span[1][0], span[1][1] + 1)) for span in spans if span[0] not in ignore_labels]


# =========================
# TXT（标注格式） → T5 数据（保持原逻辑）
# =========================
def turn_txt_to_t5_data(input_file, output_file):
    f = open(os.path.join(input_file), "r", encoding="utf-8")

    new_lines = []
    sentence = []
    label = []
    image_id = ""

    for line in f:
        if line.startswith("IMGID:"):
            image_id = line.strip()[6:]
        elif line == "\n":
            tags = _bio_tag_to_spans(label)
            tuples = []
            for tag, (i, j) in tags:
                tuples.append([" ".join(sentence[i:j]), tag, "NULL", "NULL"])
            new_line = " ".join(sentence) + "####" + str(tuples) + "####" + image_id + ".jpg"
            new_lines.append(new_line)

            sentence = []
            label = []
            image_id = ""
        else:
            parts = line.strip().split("\t")
            if not parts:
                continue
            sentence.append(parts[0])
            label.append(parts[-1])

    if sentence or label or image_id:
        tags = _bio_tag_to_spans(label)
        tuples = []
        for tag, (i, j) in tags:
            tuples.append([" ".join(sentence[i:j]), tag, "NULL", "NULL"])
        new_line = " ".join(sentence) + "####" + str(tuples) + "####" + image_id + ".jpg"
        new_lines.append(new_line)

    with open(os.path.join(output_file), "w", encoding="utf-8") as fw:
        for line in new_lines:
            fw.write(line + "\n")


# =========================
# 主流程（加入数量对齐“硬检测”）
# =========================
def main():
    labeled = True
    sample_number = 1
    for dataset in ["CT-RATE-zh"]:
        parent_dir = "../dataset/"
        for mode in ["train", "dev", "test"]:
            txt_file_path = (
                "/home/wurenji/projects/Linlinlin/GMDA/MultimodalTextGeneration/output_dir/CT-RATE-zh/lora/aug_text/CT-RATE-zh_aug_text_train-0.0002_epochs-30.txt"
            )
            if os.path.exists(txt_file_path) is False:
                print(f"{dataset} {mode} haven't been inference")
                continue

            if mode == "train":
                mode_json = "train"
            elif mode == "dev":
                mode_json = "dev"
            elif mode == "test":
                mode_json = "test"
            else:
                raise ValueError(f"Unexpected mode: {mode}")

            raw_json_file = f"{parent_dir}/{dataset}/{mode_json}.json"

            aug_json_dir = f"./aug_text_{str(sample_number)}/json/{dataset}"
            os.makedirs(aug_json_dir, exist_ok=True)
            aug_json_file = os.path.join(aug_json_dir, f"{mode_json}_all_aug.json")

            with open(txt_file_path, "r", encoding="utf-8") as file:
                aug_txt_lines = file.readlines()

            with open(raw_json_file, "r", encoding="utf-8") as file:
                raw_json_data = json.load(file)

            # === 硬检测：增强行数对齐（非空行计数）
            non_empty_aug_count = sum(1 for l in aug_txt_lines if l.strip())
            expected_total = len(raw_json_data) * sample_number
            if non_empty_aug_count != expected_total:
                raise ValueError(
                    f"[ERROR] 增强文本非空行数({non_empty_aug_count}) != 样本数*sample_number({expected_total}); "
                    f"dataset={dataset}, mode={mode}. "
                    f"请检查推理输出与样本对齐或调整 sample_number。"
                )

            # === 选择路径
            if labeled:
                if "FMNERG" in dataset:
                    aug_json_out_list = process_labeled_file_gmner_keep_all(
                        aug_txt_lines, raw_json_data, sample_number=sample_number
                    )
                else:
                    aug_json_out_list = process_labeled_file_gmner_keep_all(
                        aug_txt_lines, raw_json_data, sample_number=sample_number
                    )
            else:
                aug_json_out_list = check_and_turn_to_json(
                    aug_txt_lines, raw_json_data, sample_number=sample_number
                )

            with open(aug_json_file, "w", encoding="utf-8") as file:
                json.dump(aug_json_out_list, file, ensure_ascii=False, indent=2)

            print(f"{dataset} {mode} json file have saved in {aug_json_file}")

            # === 输出 NER TXT
            output_txt_dir = f"./aug_text_{str(sample_number)}/txt/{dataset}"
            os.makedirs(output_txt_dir, exist_ok=True)
            output_txt_file_path = os.path.join(output_txt_dir, f"{mode_json}.txt")

            if "FMNERG" in dataset:
                json_to_txt_fmnerg(aug_json_out_list, output_txt_file_path, True)
            else:
                json_to_txt_gmner(aug_json_out_list, output_txt_file_path, True)

            print(f"{dataset} {mode} txt file have saved in {output_txt_file_path}")

            # === 输出 T5 文本
            output_T5_format_txt_dir = f"./aug_text_{str(sample_number)}/t5_data/{dataset}"
            os.makedirs(output_T5_format_txt_dir, exist_ok=True)
            output_T5_format_txt_file_path = os.path.join(
                output_T5_format_txt_dir, f"{mode_json}.txt"
            )

            turn_txt_to_t5_data(output_txt_file_path, output_T5_format_txt_file_path)

            print(f"{dataset} {mode} t5 format txt file have saved in {output_T5_format_txt_file_path}")


if __name__ == "__main__":
    main()
