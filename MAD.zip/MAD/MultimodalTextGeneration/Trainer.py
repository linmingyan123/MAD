import os
import re
import json
from tqdm import tqdm
from torch.utils.data import DataLoader
from torch.optim import AdamW
from tree import coarse_fine_tree

def load_bio_entities(path):
    samples = {}

    cur_id = None
    tokens = []
    tags = []

    def flush():
        nonlocal cur_id, tokens, tags
        if cur_id is None or not tokens:
            return

        entities = []
        buf = []
        buf_type = None

        for tok, tag in zip(tokens, tags):
            if tag.startswith("B-"):
                if buf:
                    entities.append({"text": "".join(buf), "type": buf_type})
                buf = [tok]
                buf_type = tag[2:]
            elif tag.startswith("I-") and buf_type == tag[2:]:
                buf.append(tok)
            else:
                if buf:
                    entities.append({"text": "".join(buf), "type": buf_type})
                    buf = []
                    buf_type = None

        if buf:
            entities.append({"text": "".join(buf), "type": buf_type})

        uniq = {}
        for e in entities:
            uniq[(e["text"], e["type"])] = e
        samples[cur_id] = list(uniq.values())

        tokens = []
        tags = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if not s:
                flush()
                cur_id = None
                continue

            if s.startswith("image_id:"):
                flush()
                cur_id = s.split(":", 1)[1].strip()
                tokens = []
                tags = []
                continue

            parts = s.split()
            if len(parts) != 2:
                continue
            tok, tag = parts
            tokens.append(tok)
            tags.append(tag)

    flush()
    return samples


# ==============================================================
# Trainer 类
# ==============================================================
class Trainer:
    def __init__(
        self,
        model,
        args,
        criterion,
        processor,
        data_collator,
        train_dataset=None,
        eval_dataset=None,
        test_dataset=None,
        **kwargs
    ):
        self.args = args
        self.train_batch_size = kwargs.get("train_batch_size", 4)
        self.eval_batch_size = kwargs.get("eval_batch_size", 4)
        self.trainable_mode = kwargs.get("trainable_mode", None)
        self.num_train_epochs = kwargs.get("num_train_epochs", 3)

        self.device = next(model.parameters()).device
        self.model = model
        self.criterion = criterion
        self.processor = processor
        self.generate_text_dir = "./augmented_text"

        # ----- DataLoaders -----
        if train_dataset is not None:
            self.train_loader = DataLoader(
                train_dataset,
                batch_size=self.train_batch_size,
                shuffle=True,
                collate_fn=data_collator,
            )
        else:
            self.train_loader = None

        if eval_dataset is not None:
            self.eval_loader = DataLoader(
                eval_dataset,
                batch_size=self.eval_batch_size,
                collate_fn=data_collator,
            )
        else:
            self.eval_loader = None

        if test_dataset is not None:
            self.test_loader = DataLoader(
                test_dataset,
                batch_size=self.eval_batch_size,
                collate_fn=data_collator,
            )
        else:
            self.test_loader = None

        # ----- Optimizer -----
        lr = float(getattr(args, "lr", 1e-5))
        wd = float(getattr(args, "weight_decay", 0.01))
        self.optimizer = AdamW(
            (p for p in self.model.parameters() if p.requires_grad),
            lr=lr,
            weight_decay=wd,
        )

    # =============================================================
    # 工具：简单清理文本
    # =============================================================
    def clean_text(self, s):
        s = s.strip().replace("\n", "")
        s = re.sub(r"\s+", " ", s)
        return s

    # =============================================================
    # LLM 生成函数
    # =============================================================
    def run_generation(self, prompt):
        try:
            inputs = self.processor.tokenizer(
                prompt,
                return_tensors="pt",
                truncation=True,
                max_length=1024,
            ).to(self.device)

            outputs = self.model.generate(
                **inputs,
                do_sample=True,
                top_k=50,
                top_p=0.9,
                temperature=0.7,
                max_new_tokens=512,
                repetition_penalty=1.05,
            )
            text = self.processor.tokenizer.decode(outputs[0], skip_special_tokens=True)
            return text.strip()
        except Exception as e:
            print("❌ 生成失败：", e)
            return None

    # =============================================================
    # Step1: 单句仿写（实体保护）
    # =============================================================
    def generate_aug_sentence(self, raw_sentence, entities):
        """
        entities: list[(entity_text, entity_type)]
        用 __实体__ 占位保护实体，然后让 LLM 仿写，再把实体替换回来
        """
        protected = raw_sentence
        for ent, etype in entities:
            if ent:
                protected = protected.replace(ent, f"__{ent}__")

        prompt = (
            "请对以下医学句子进行语义仿写，保持所有医学实体不变，使句子更加自然流畅：\n"
            f"{protected}\n"
            "仿写："
        )

        gen_text = self.run_generation(prompt)
        if not gen_text:
            gen_text = protected

        for ent, etype in entities:
            if ent:
                gen_text = gen_text.replace(f"__{ent}__", ent)

        return self.clean_text(gen_text)

    # =============================================================
    # Step1: 批量生成仿写句子 → aug_sentence.txt
    # =============================================================
    def aug_data_generate(self, dataset="medical", num_return_sequences=5):
        if self.train_loader is None:
            raise ValueError("train_loader 为空，无法生成增强数据")

        base_root = "/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/augmented"
        out_dir = os.path.join(base_root, "txt_raw_sentence", dataset)
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, "aug_sentence.txt")

        dataset_ref = self.train_loader.dataset

        print(f"🔥 开始生成仿写句子 → {out_path}")
        with open(out_path, "w", encoding="utf-8") as f:
            for item in tqdm(dataset_ref):
                raw_sentence = item["sentence"]
                image_id = item["image_id"]

                entities = []
                for etype, terms in coarse_fine_tree.items():
                    for term in terms:
                        if term and term in raw_sentence:
                            entities.append((term, etype))

                for k in range(num_return_sequences):
                    aug_sentence = self.generate_aug_sentence(raw_sentence, entities)
                    f.write(f"image_id:{image_id}_aug{k+1}\n")
                    f.write(aug_sentence + "\n\n")

        print(f"✨ 仿写句子已写入：{out_path}")

    # =============================================================
    # Step2: aug_sentence.txt + 原始 train.txt → 新 BIO + JSON
    # =============================================================
    def convert_txt_to_bio_and_json(self, txt_path, orig_bio_path, out_json_path, out_bio_path):
        print(f"📌 从原始 BIO 加载实体：{orig_bio_path}")
        id2entities = load_bio_entities(orig_bio_path)
        print(f"   实体样本数：{len(id2entities)}")

        with open(txt_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        bio_out = open(out_bio_path, "w", encoding="utf-8")
        all_json = []

        cur_id = None
        cur_lines = []

        def process_block(image_id_aug, block_lines):
            if not block_lines:
                return

            full_text = "\n".join(block_lines).strip()

            if "仿写：" in full_text:
                sentence = full_text.split("仿写：", 1)[1].strip()
            else:
                sentence = full_text

            sentence = sentence.replace("\n", "").strip()
            if not sentence:
                return

            chars = list(sentence)
            tags = ["O"] * len(chars)

            orig_id = image_id_aug.split("_aug", 1)[0]
            if orig_id not in id2entities:
                print(f"⚠️ 原始 BIO 中找不到实体信息：{orig_id}，跳过 {image_id_aug}")
                return

            entities = id2entities[orig_id]  # [{"text":..., "type":...}, ...]

            # =========================
            # ✅ 改动：优先匹配长实体（按长度降序）
            # 同时避免短实体覆盖长实体已标注区
            # =========================
            entities = sorted(
                (e for e in entities if e.get("text")),
                key=lambda e: len(e["text"]),
                reverse=True
            )

            for ent in entities:
                ent_text = ent["text"]
                ent_type = ent["type"]
                L = len(ent_text)
                if L == 0:
                    continue

                start = 0
                while True:
                    pos = sentence.find(ent_text, start)
                    if pos == -1:
                        break

                    # ✅ 改动：如果该跨度已被更长实体占用，则跳过（防覆盖）
                    span_ok = True
                    for i in range(L):
                        idx = pos + i
                        if idx < 0 or idx >= len(chars):
                            span_ok = False
                            break
                        if tags[idx] != "O":
                            span_ok = False
                            break

                    if span_ok:
                        for i in range(L):
                            idx = pos + i
                            if i == 0:
                                tags[idx] = f"B-{ent_type}"
                            else:
                                tags[idx] = f"I-{ent_type}"

                    start = pos + 1  # 继续搜索（保留你原来的策略）

            bio_out.write(f"image_id:{image_id_aug}\n")
            for ch, tg in zip(chars, tags):
                bio_out.write(f"{ch} {tg}\n")
            bio_out.write("\n")

            all_json.append({
                "image_id": image_id_aug,
                "tokens": chars,
                "tags": tags,
                "sentence": sentence,
            })

        for line in lines:
            s = line.strip()
            if not s:
                if cur_id is not None:
                    process_block(cur_id, cur_lines)
                cur_id = None
                cur_lines = []
                continue

            if s.startswith("image_id:"):
                if cur_id is not None:
                    process_block(cur_id, cur_lines)
                cur_id = s.split(":", 1)[1].strip()
                cur_lines = []
            else:
                cur_lines.append(s)

        if cur_id is not None:
            process_block(cur_id, cur_lines)

        bio_out.close()

        with open(out_json_path, "w", encoding="utf-8") as jf:
            json.dump(all_json, jf, ensure_ascii=False, indent=2)

        print(f"✅ BIO 输出：{out_bio_path}")
        print(f"✅ JSON 输出：{out_json_path}")
