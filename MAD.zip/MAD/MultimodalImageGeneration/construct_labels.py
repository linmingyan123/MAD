import numpy as np
from collections import defaultdict


def read_bio_file(path):
    imgid2_entities = defaultdict(list)

    cur_imgid = None
    cur_tokens = []
    cur_labels = []

    def flush_sentence():
        nonlocal cur_tokens, cur_labels, cur_imgid
        if not cur_tokens or cur_imgid is None:
            cur_tokens, cur_labels = [], []
            return

        i = 0
        n = len(cur_labels)
        while i < n:
            lab = cur_labels[i]
            if lab == "O":
                i += 1
                continue
            if lab.startswith("B-"):
                ent_type = lab.split("-")[1]  # organ / disease / tissue / process / other ...
                start = i
                i += 1
                while i < n and cur_labels[i].startswith("I-"):
                    i += 1
                end = i - 1
                ent_text = "".join(cur_tokens[start:end + 1])
                imgid2_entities[cur_imgid].append((ent_text, ent_type))
            else:
                ent_type = lab.split("-")[1]
                start = i
                i += 1
                while i < n and cur_labels[i].startswith("I-"):
                    i += 1
                end = i - 1
                ent_text = "".join(cur_tokens[start:end + 1])
                imgid2_entities[cur_imgid].append((ent_text, ent_type))

        cur_tokens, cur_labels = [], []

    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                flush_sentence()  # 处理一行结束的情况
                continue
            if line.startswith("image_id"):  # 改为检查 image_id
                print(f"读取到 image_id: {line}")  # 调试输出，检查是否正确读取
                flush_sentence()  # 处理上一条报告
                cur_imgid = line.split("image_id")[-1].strip()  # 获取当前报告的 ID
                continue

            parts = line.split()
            if len(parts) < 2:
                continue
            char, lab = parts[0], parts[1]
            cur_tokens.append(char)
            cur_labels.append(lab)

    flush_sentence()  # 最后一条数据结束时调用
    return imgid2_entities


def build_vocabs(imgid2_entities):
    disease_set = set()
    organ_set = set()

    for imgid, ents in imgid2_entities.items():
        for ent_text, ent_type in ents:
            if ent_type == "disease":
                disease_set.add(ent_text)
            elif ent_type == "organ":
                organ_set.add(ent_text)

    disease_vocab = sorted(list(disease_set))
    organ_vocab = sorted(list(organ_set))

    disease2idx = {e: i for i, e in enumerate(disease_vocab)}
    organ2idx = {e: i for i, e in enumerate(organ_vocab)}

    return disease_vocab, organ_vocab, disease2idx, organ2idx


def build_multilabel_targets(imgid2_entities, disease2idx, organ2idx):
    imgid2_y_disease = {}
    imgid2_y_organ = {}

    for imgid, ents in imgid2_entities.items():
        y_d = np.zeros(len(disease2idx), dtype=int)
        y_o = np.zeros(len(organ2idx), dtype=int)

        for ent_text, ent_type in set(ents):  # 去重
            if ent_type == "disease" and ent_text in disease2idx:
                y_d[disease2idx[ent_text]] = 1
            elif ent_type == "organ" and ent_text in organ2idx:
                y_o[organ2idx[ent_text]] = 1

        imgid2_y_disease[imgid] = y_d
        imgid2_y_organ[imgid] = y_o

    return imgid2_y_disease, imgid2_y_organ


def main():
    # 1. 读取 BIO 文件
    bio_file_path = "/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/med_augmented0.4/medical_train.txt"
    imgid2_entities = read_bio_file(bio_file_path)

    # 打印读取到的实体
    print(f"读取到的实体数量: {sum(len(ents) for ents in imgid2_entities.values())}")
    print("部分实体样例:")
    for imgid, ents in list(imgid2_entities.items())[:5]:  # 只打印前 5 个报告
        print(f"IMGID: {imgid}, 实体: {ents}")

    # 2. 构建词表
    disease_vocab, organ_vocab, disease2idx, organ2idx = build_vocabs(imgid2_entities)

    # 3. 构建多标签向量
    imgid2_y_disease, imgid2_y_organ = build_multilabel_targets(imgid2_entities, disease2idx, organ2idx)

    # 输出结果查看
    print("打印部分多标签向量:")
    for imgid in list(imgid2_y_disease.keys())[:5]:
        print(f"IMGID: {imgid}")
        print(f"y_disease: {imgid2_y_disease[imgid]}")
        print(f"y_organ: {imgid2_y_organ[imgid]}")
        print("------")

    # 保存到文件
    print("保存到文件...")
    with open("/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/0.4-medi_labels.txt", "w") as f:
        for imgid in imgid2_y_disease:
            f.write(f"IMGID{imgid}\n")
            f.write(f"y_disease: {imgid2_y_disease[imgid]}\n")
            f.write(f"y_organ: {imgid2_y_organ[imgid]}\n")
            f.write("------\n")


if __name__ == "__main__":
    main()
