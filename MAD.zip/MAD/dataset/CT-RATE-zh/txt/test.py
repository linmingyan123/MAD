#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
from pathlib import Path

# ======== 修改为你的真实路径 ========
INPUT_FILE = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/biaozhu.txt")

TRAIN_FILE = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/train.txt")
TEST_FILE  = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/test.txt")
DEV_FILE   = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/dev.txt")

# 固定随机种子，保证每次划分一致（想要不同随机划分就改这个数）
random.seed(42)


def load_samples_by_imgid(path: Path):
    """
    按 'IMGID:' 开头行切分样本。
    每个样本是一个字符串（内部已经包含换行）。
    """
    samples = []
    current_lines = []

    with path.open("r", encoding="utf-8") as f:
        for raw in f:
            line = raw.rstrip("\n")

            # 遇到新的 IMGID，说明上一条样本结束了
            if line.startswith("IMGID:"):
                # 把上一条收进去
                if current_lines:
                    samples.append("\n".join(current_lines))
                    current_lines = []
                current_lines.append(line)
            else:
                # 普通标注行
                if line.strip() == "" and not current_lines:
                    # 文件开头可能有空行，直接跳过
                    continue
                current_lines.append(line)

        # 文件结束，补上最后一条
        if current_lines:
            samples.append("\n".join(current_lines))

    return samples


def write_samples(path: Path, sample_list):
    """写出样本，每条样本之间空一行"""
    with path.open("w", encoding="utf-8") as f:
        for idx, sample in enumerate(sample_list):
            f.write(sample)
            if idx != len(sample_list) - 1:
                f.write("\n\n")  # 两条之间空行


def main():
    samples = load_samples_by_imgid(INPUT_FILE)

    total = len(samples)
    print(f"共读取样本数: {total}")

    if total == 0:
        print("⚠️ 没有读到任何样本，请检查 INPUT_FILE 路径和格式。")
        return

    # 按 8:1:1 划分
    n_train = int(total * 0.8)
    n_test = int(total * 0.1)
    n_dev = total - n_train - n_test  # 保证总数不丢失

    random.shuffle(samples)

    train_samples = samples[:n_train]
    test_samples  = samples[n_train:n_train + n_test]
    dev_samples   = samples[n_train + n_test:]

    write_samples(TRAIN_FILE, train_samples)
    write_samples(TEST_FILE, test_samples)
    write_samples(DEV_FILE, dev_samples)

    print(f"train: {len(train_samples)}, test: {len(test_samples)}, dev: {len(dev_samples)}")
    print("✅ 划分完成！")


if __name__ == "__main__":
    main()
