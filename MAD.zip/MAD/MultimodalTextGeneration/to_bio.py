import json
import re

def load_meta_json(json_path):
    """
    从 train_all_aug.json 加载模型生成的原句、仿写句、实体等信息
    格式：
    [
      {
        "raw_sentence": "...",
        "sentence": "...",
        "entities": [...],
        "image_id": "xxxx_aug1"
      },
      ...
    ]
    """
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    meta = {}
    for item in data:
        meta[item["image_id"]] = {
            "raw_sentence": item.get("raw_sentence", ""),
            "sentence": item.get("sentence", ""),
            "entities": item.get("entities", [])
        }
    return meta


def convert_bio_to_json(bio_path, meta_json_path, output_path):
    """
    只输出以下结构：
    {
      "raw_sentence": "...",
      "sentence": "...",
      "entities": [...],
      "image_id": "xxx_aug1"
    }
    """
    meta = load_meta_json(meta_json_path)

    results = []
    cur_id = None
    chars = []
    labels = []

    def flush_sample():
        nonlocal cur_id, chars, labels
        if cur_id is None or len(chars) == 0:
            chars, labels = [], []
            return

        # 拼接文本（不截断）
        text = "".join(chars)

        # ==== 修复数字单位等被拆开的问题 ====
        text = re.sub(r"\s+", "", text)
        text = re.sub(r"(\d)\s*\.\s*(\d)", r"\1.\2", text)
        text = re.sub(r"(\d)\s*([a-zA-Z厘米毫米cmMM])", r"\1\2", text)
        text = re.sub(r"([a-zA-Z%])\s*(\d)", r"\1\2", text)
        text = re.sub(r"\s*([，。；：,.])\s*", r"\1", text)
        text = text.strip()

        # 取 meta 信息
        if cur_id in meta:
            raw_sentence = meta[cur_id]["raw_sentence"]
            sentence = meta[cur_id]["sentence"]
            entities = meta[cur_id]["entities"]
        else:
            raw_sentence = ""
            sentence = text
            entities = []

        # ⬇⬇⬇ 输出 EXACT 你要的数据结构
        results.append({
            "raw_sentence": raw_sentence,
            "sentence": sentence,
            "entities": entities,
            "image_id": cur_id
        })

        chars, labels = [], []

    # ======== 读取 BIO 文件 ========
    with open(bio_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line:
                flush_sample()
                continue

            if line.startswith("image_id:"):
                flush_sample()
                cur_id = line.split("image_id:")[-1].strip()
                continue

            parts = line.split()
            if len(parts) != 2:
                continue

            ch, tag = parts
            chars.append(ch)
            labels.append(tag)

    flush_sample()

    # 写出最终你要的 JSON 结构
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"✅ 完成！共 {len(results)} 条记录")
    print(f"📁 输出文件：{output_path}")


# =======================
#        程序入口
# =======================
if __name__ == "__main__":
    # 输入路径
    bio_path = "/home/wurenji/projects/Linlinlin/GMDA/MultimodalTextGeneration/augmented/txt/medical/train_all_aug.txt"        # 输入 BIO txt
    meta_json_path = "/home/wurenji/projects/Linlinlin/GMDA/MultimodalTextGeneration/augmented/json/medical/train_all_aug.json" # 输入生成句子的 json
    output_path = "/home/wurenji/projects/Linlinlin/GMDA/MultimodalTextGeneration/augmented/txt/medical/final.json"     # 输出最终 json

    convert_bio_to_json(bio_path, meta_json_path, output_path)
