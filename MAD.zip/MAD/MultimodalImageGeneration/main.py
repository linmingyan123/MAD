import os
import re
import json
import glob
import torch
import numpy as np
import traceback
from PIL import Image
import cv2
import nibabel as nib
from diffusers import StableDiffusionImg2ImgPipeline
from skimage.metrics import structural_similarity as ssim

os.environ["CUDA_VISIBLE_DEVICES"] = "4"  # 改为你的 GPU ID
device = "cuda" if torch.cuda.is_available() else "cpu"
def main():
    # ========== 基础配置 ==========
    model_id_or_path = "/home/wurenji/projects/Linlinlin/GMDA/stable-diffusion-v1-5"
    img_dir = "/home/wurenji/projects/Linlinlin/MAD/medical_nii/your_output_folder"  # 原始 NIfTI 图像目录

    DATASET = "medical"
    SAMPLE_SET = ["train"]
    json_root = f"/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/med_augmented0.1"
    json_paths = [os.path.join(json_root, f"{DATASET}_{m}_all_aug.json") for m in SAMPLE_SET]

    # 输出目录：现在是 基于“原图 + 文本 + 标签”的 img2img
    output_image_dir = f"./diff_image/{DATASET}_0.1medi"
    os.makedirs(output_image_dir, exist_ok=True)
    target_size = (512, 512)

    # ========== 加载 Stable Diffusion Img2Img 模型 ==========
    print("🚀 正在加载 StableDiffusionImg2ImgPipeline ...")
    pipe = StableDiffusionImg2ImgPipeline.from_pretrained(
        model_id_or_path,
        torch_dtype=torch.float16 if device == "cuda" else torch.float32
    ).to(device)

    pipe.enable_attention_slicing("max")
    pipe.enable_vae_slicing()

    def dummy_checker(images, **kwargs):
        return images, [False] * len(images)

    pipe.safety_checker = dummy_checker

    generator = torch.Generator(device).manual_seed(42)

    # ========== 工具函数 ==========
    def compute_ssim(img1, img2):
        """计算两张 PIL 图像的结构相似度 (SSIM)"""
        arr1 = np.array(img1.convert('L'), dtype=np.float32) / 255.0
        arr2 = np.array(img2.convert('L'), dtype=np.float32) / 255.0
        return ssim(arr1, arr2, data_range=1.0)

    def find_matching_nii(img_id, img_dir_):
        """
        只用 `_aug` 前面的那串数字去匹配 NIfTI 文件。
        例如:
            img_id = '2480345_aug2' -> base_id = '2480345'
        然后匹配:
            2480345.nii
            2480345_*.nii
            2480345.nii.gz
            2480345_*.nii.gz
        """
        # 先按 '_aug' 切分，取前半部分
        base_part = img_id.split('_aug')[0]

        # 再从前半部分里面提取“开头的一段数字”
        m = re.match(r'(\d+)', base_part)
        if m:
            base_id = m.group(1)
        else:
            # 如果没匹配到数字，就直接用前半部分
            base_id = base_part

        # 构造几种常见的匹配模式
        patterns = [
            os.path.join(img_dir_, f"{base_id}.nii"),
            os.path.join(img_dir_, f"{base_id}_*.nii"),
            os.path.join(img_dir_, f"{base_id}.nii.gz"),
            os.path.join(img_dir_, f"{base_id}_*.nii.gz"),
        ]

        matched = []
        for p in patterns:
            matched.extend(glob.glob(p))

        return matched

    def preprocess_slice(mid_slice):
        """预处理切片，减少伪影，并做对比度拉伸"""
        arr = np.clip(mid_slice, np.percentile(mid_slice, 1), np.percentile(mid_slice, 99))
        arr = (arr - np.min(arr)) / (np.max(arr) - np.min(arr) + 1e-8) * 255
        arr = arr.astype(np.uint8)
        arr = cv2.medianBlur(arr, 3)
        arr = cv2.equalizeHist(arr)
        return arr

    def read_labels(file_path):
        """读取 medical_labels.txt 标签"""
        imgid2_labels = {}
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read().strip().split("------")
            for section in content:
                lines = section.strip().splitlines()
                imgid = None
                y_disease = None
                y_organ = None
                for line in lines:
                    if line.startswith("IMGID:"):
                        imgid = line.split(":", 1)[1].strip()
                    elif line.startswith("y_disease:"):
                        y_disease = list(map(int, re.findall(r'\d+', line)))
                    elif line.startswith("y_organ:"):
                        y_organ = list(map(int, re.findall(r'\d+', line)))
                if imgid and y_disease is not None and y_organ is not None:
                    imgid2_labels[imgid] = {'y_disease': y_disease, 'y_organ': y_organ}
        print(f"✅ 读取到 {len(imgid2_labels)} 个图像标签")
        return imgid2_labels

    # ========== 读取标签 ==========
    label_file_path = "/home/wurenji/projects/Linlinlin/MAD/MultimodalTextGeneration/0.1-medi_labels.txt"  # 改成你本地路径
    imgid2_labels = read_labels(label_file_path)

    # ========== 读取 JSON 文件 ==========
    all_sets_data = []
    for jp in json_paths:
        if not os.path.exists(jp):
            print(f"⚠️ 文件不存在: {jp}")
            continue
        with open(jp, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                all_sets_data.append(("train", data))
                print(f"✅ 读取 JSON: {jp}, 样本数 = {len(data)}")
            except Exception as e:
                print(f"❌ 读取 JSON 失败: {jp}, 错误: {e}")

    # ========== 生成图像 ==========
    print("\n🎨 开始基于【原图 + 文本 + 标签】生成图像...")
    for mode, data in all_sets_data:
        for idx, item in enumerate(data):
            img_id = str(item["image_id"]).strip()
            sentence = item["sentence"]
            # 去掉 URL 等噪声
            sentence = ' '.join([w for w in sentence.split() if "http" not in w])

            if img_id not in imgid2_labels:
                print(f"⚠️ [{idx+1}/{len(data)}] {img_id} 无标签，跳过")
                continue

            labels = imgid2_labels[img_id]
            y_disease = labels['y_disease']
            y_organ = labels['y_organ']

            # 构建标签描述（这里还是用占位符，你可以换成真实疾病/器官名）
            disease_description = ", ".join([f"Disease {i}" for i, v in enumerate(y_disease) if v == 1]) or "no disease"
            organ_description = ", ".join([f"Organ {i}" for i, v in enumerate(y_organ) if v == 1]) or "normal organs"

            # 👉 这里融合：标签 + 文本 sentence
            curr_prompt = (
                f"A CT image showing {disease_description} and {organ_description}. "
                f"High-quality, realistic radiology image. Clinical description: {sentence}"
            )

            out_path = os.path.join(output_image_dir, f"{img_id}.jpg")
            if os.path.exists(out_path):
                print(f"⏩ [{idx+1}/{len(data)}] 已存在: {out_path}")
                continue

            # ===== 读取并预处理原始 NIfTI 图像，作为 Img2Img 的条件 =====
            matched_paths = find_matching_nii(img_id, img_dir)
            if not matched_paths:
                print(f"⚠️ [{idx+1}/{len(data)}] 找不到匹配的 NIfTI 文件，对应 img_id={img_id}，跳过")
                continue

            nii_path = matched_paths[0]
            try:
                nii_img = nib.load(nii_path)
                nii_data = nii_img.get_fdata()

                # 取中间层
                mid_slice = nii_data[:, :, nii_data.shape[2] // 2]
                if mid_slice.shape[0] == 0 or mid_slice.shape[1] == 0:
                    print(f"⚠️ [{idx+1}/{len(data)}] 图像尺寸为 0：{img_id}, shape={mid_slice.shape}，跳过")
                    continue

                arr = preprocess_slice(mid_slice)
                # 调整到 target_size
                arr = cv2.resize(arr, target_size, interpolation=cv2.INTER_LINEAR)
                init_image = Image.fromarray(arr).convert("RGB")

            except Exception as e:
                print(f"❌ [{idx+1}/{len(data)}] 处理 NIfTI 失败: {nii_path}, 错误: {e}")
                traceback.print_exc()
                continue

            # ===== 使用原图 + prompt 做 Img2Img 生成 =====
            try:
                with torch.inference_mode():
                    result = pipe(
                        prompt=curr_prompt,
                        image=init_image,
                        strength=0.7,          # 越小越贴近原图，越大越像重绘
                        guidance_scale=7.0,
                        num_inference_steps=30,
                        generator=generator,
                    )
                    gen_img = result.images[0]

                    # 计算原图和生成图的 SSIM（可选）
                    try:
                        ssim_val = compute_ssim(init_image, gen_img)
                        print(f"✅ [{idx+1}/{len(data)}] 已生成: {out_path}，SSIM={ssim_val:.4f}")
                    except Exception as e_ssim:
                        print(f"⚠️ [{idx+1}/{len(data)}] 计算 SSIM 失败: {e_ssim}")
                        print(f"✅ [{idx+1}/{len(data)}] 已生成: {out_path}")

                    gen_img.save(out_path)

            except Exception as e:
                print(f"❌ [{idx+1}/{len(data)}] {img_id} 生成失败: {e}")
                traceback.print_exc()
                continue

    print("\n🏁 图像生成完毕。")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("程序发生未捕获的致命错误：")
        traceback.print_exc()
        input("按回车键退出...")
