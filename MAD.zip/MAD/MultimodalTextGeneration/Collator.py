# Collator.py  —— minimal GMNER (sentence/entities only)
import os
import numpy as np
from PIL import Image

class Collator:
    def __init__(self, processor, task, img_file_path, text_need=True):
        """
        Args:
            processor: InstructBlipProcessor
            img_file_path: 图像根目录（用于相对路径补全或仅给出 image_id 的情况）
            text_need: 是否生成图像提示文本（给模型的 text 输入）
        """
        self.processor = processor
        self.img_file_path = img_file_path
        self.text_need = text_need
        self._dbg_once = False
        self.task = task

    # ---------- image loaders ----------
    def _resolve_image_path(self, sample):
        """
        仅支持两种字段：
          - sample["image_path"]：绝对/相对路径，带或不带扩展名
          - sample["image_id"]：不带路径；自动补 '.npz'
        """
        if "image_path" in sample and sample["image_path"]:
            p = str(sample["image_path"])
            # 绝对路径或包含目录 -> 原样；否则与 img_file_path 拼接
            if os.path.isabs(p) or os.path.dirname(p):
                return p
            return os.path.join(self.img_file_path, p)

        if "image_id" in sample and sample["image_id"]:
            image_id = str(sample["image_id"])
            if not image_id.endswith(".npz"):
                image_id += ".npz"
            return os.path.join(self.img_file_path, image_id)

        raise KeyError(f"No image_path/image_id in sample keys={list(sample.keys())}")

    def _load_npz_as_image(self, path):
        data = np.load(path)
        # 取第一个 ndarray
        key = next((k for k in data.files if isinstance(data[k], np.ndarray)), None)
        if key is None:
            raise ValueError(f"No ndarray found in npz: {path}")
        arr = data[key]

        # CHW -> HWC
        if arr.ndim == 3 and arr.shape[0] in (1, 3) and arr.shape[0] < arr.shape[-1]:
            arr = np.moveaxis(arr, 0, -1)
        # 灰度 -> 3 通道
        if arr.ndim == 2:
            arr = arr[..., None]
        # 归一化到 uint8
        if arr.dtype != np.uint8:
            a = arr.astype(np.float32)
            if 0.0 <= a.min() <= a.max() <= 1.0:
                a = a * 255.0
            else:
                rng = a.max() - a.min()
                a = (a - a.min()) / (rng + 1e-8) * 255.0
            arr = a.clip(0, 255).astype(np.uint8)
        if arr.shape[-1] == 1:
            arr = np.repeat(arr, 3, axis=-1)
        elif arr.shape[-1] > 3:
            arr = arr[..., :3]
        return Image.fromarray(arr, mode="RGB")

    def _load_image_from_sample(self, sample):
        path = self._resolve_image_path(sample)
        ext = os.path.splitext(path)[1].lower()
        if ext == "":
            # 默认当作 npz
            path = path + ".npz"
            ext = ".npz"
        if not os.path.isabs(path):
            path = os.path.join(self.img_file_path, path)
        if ext in (".npz", ".npy"):
            return self._load_npz_as_image(path)
        return Image.open(path).convert("RGB")

    # ---------- text helpers ----------
    def _get_sentence(self, sample):
        s = sample.get("sentence", "")
        if s is None:
            s = ""
        if not isinstance(s, str):
            s = " ".join(map(str, s))
        return s if s.strip() != "" else ""

    def _normalize_entities(self, sample):
        ents = sample.get("entities", []) or []
        # 只保留 {text, tag}
        norm = []
        for e in ents:
            text = str(e.get("text", "")).strip()
            tag = str(e.get("tag", "")).strip() or "OTHER"
            if text:
                norm.append({"text": text, "tag": tag})
        return norm

    def _add_annotation_in_sentence(self, sentence, entities):
        """GMNER：将实体以 BIO 的形式嵌入原句（用简单替换法）"""
        if not sentence.strip() or not entities:
            return sentence
        tagged = sentence
        for e in entities:
            tokens = e["text"].split()
            if not tokens:
                continue
            rep = f"B-{e['tag']} {tokens[0]}" + " ".join([f" I-{e['tag']} {t}" for t in tokens[1:]])
            tagged = tagged.replace(e["text"], rep)
        return tagged

    # ---------- main ----------
    def __call__(self, batch):
        # 过滤空样本
        batch = [b for b in batch if b is not None]
        batch = [b for b in batch if self._get_sentence(b) != ""]  # 丢弃空句子
        if len(batch) == 0:
            return {"inputs": None, "outputs": []}

        # 准备图像与文本
        images = [self._load_image_from_sample(b) for b in batch]
        sentences = [self._get_sentence(b) for b in batch]
        entities = [self._normalize_entities(b) for b in batch]

        # 目标（带 BIO）
        target_sentences = [
            self._add_annotation_in_sentence(s, e) for s, e in zip(sentences, entities)
        ]

        # 输入提示文本（可按需改成你的 prompt）
        if self.text_need:
            prefix = "Generate a tweet-like text based on the image with these entities: "
            texts = [
                prefix + ", ".join(f"{e['text']} ({e['tag']})" for e in ent) if ent else prefix.strip()
                for ent in entities
            ]
        else:
            texts = ["Describe the image." for _ in batch]

        # 调 tokenizer + processor
        inputs = self.processor(
            text=texts,
            images=images,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=512,
        )
        dec = self.processor(
            text=target_sentences,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=512,
        )

        # 生成 labels，并屏蔽 padding
        labels = dec["input_ids"].clone()
        tok = getattr(self.processor, "tokenizer", None)
        # 若 tokenizer 没 pad_token，设为 eos
        if tok is not None and getattr(tok, "pad_token_id", None) is None and getattr(tok, "eos_token", None) is not None:
            tok.pad_token = tok.eos_token
        pad_id = getattr(tok, "pad_token_id", None) if tok is not None else None
        attn = dec.get("attention_mask", None)
        if attn is not None:
            labels[attn == 0] = -100
        if pad_id is not None:
            labels[labels == pad_id] = -100
        inputs["labels"] = labels

        # 一次性调试打印（可删除）
        if not self._dbg_once:
            self._dbg_once = True
            try:
                valid_ratio = (labels != -100).float().mean().item()
                avg_len = (labels != -100).sum(dim=1).float().mean().item()
                print(f"[COLLATOR] labels_valid_ratio={valid_ratio:.6f}, avg_target_len={avg_len:.2f}")
            except Exception as e:
                print(f"[COLLATOR] dbg failed: {e}")

        return {"inputs": inputs, "outputs": sentences}
