# MAD

This repository contains the code implementation for the paper [MAD: Entity-Preserving Paraphrase and Structure-Constrained i2i Augmentation for Chinese CT Multimodal Named Entity Recognition]

##dataset
The CT-RATE-zh dataset is constructed by collecting raw data from the Internet, translating them into Chinese using the GPT-4 large model, and then annotating the data following the method described in our paper. The link to the original data is provided below:https://huggingface.co/datasets/ibrahimhamamci/CT-RATE/tree/main.


##code Usage

python MultimodalTextGeneration/main.pymain.py
python MultimodalImageGeneration/construct_labels.py
python MultimodalImageGeneration/main.py