#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
from pathlib import Path
from collections import defaultdict

# ====== 输入两个文件路径 ======
FILE1 = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/train.json")
FILE2 = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/dev.json")
FILE3 = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/test.json")

# ====== 输出文件路径 ======
OUTPUT_FILE = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/medical/entity_tree.json")

# ====== 标签映射（可按需扩展） ======
TAG_MAP = {
    "DISEASE": "disease",
    "ORGAN": "organ",
    "TISSUE": "tissue",
    "PROCESS": "process",
    "OTHER": "other",
}

def load_entities(file_path):
    """从一个 JSON 文件加载所有实体"""
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    entities = defaultdict(set)  # 用 set 去重
    for item in data:
        for ent in item.get("entities", []):
            tag = ent.get("tag", "").upper().strip()
            text = ent.get("text", "").strip()
            if not tag or not text:
                continue
            tag_lower = TAG_MAP.get(tag, "other")
            entities[tag_lower].add(text)
    return entities

def merge_entities(*entity_dicts):
    """合并多个实体统计字典"""
    merged = defaultdict(set)
    for dic in entity_dicts:
        for k, v in dic.items():
            merged[k].update(v)
    return merged

def main():
    ent1 = load_entities(FILE1)
    ent2 = load_entities(FILE2)
    ent3 = load_entities(FILE3)
    merged = merge_entities(ent1, ent2, ent3)

    # 转成最终格式（列表并排序）
    coarse_fine_tree = {k: sorted(list(v)) for k, v in merged.items()}

    # 打印结果
    print(json.dumps(coarse_fine_tree, ensure_ascii=False, indent=4))

    # 保存为 JSON 文件
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(coarse_fine_tree, f, ensure_ascii=False, indent=4)

    print(f"✅ 实体统计已保存至: {OUTPUT_FILE.resolve()}")

if __name__ == "__main__":
    main()
