#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

# ======== 输入路径（修改为你的路径） ========
INPUT_FILES = [
    Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/train.txt"),
    Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/test.txt"),
    Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/dev.txt"),
]
OUTPUT_FILE = Path("/home/wurenji/projects/Linlinlin/GMDA/dataset/CT-RATE-zh/txt/biaozhu.txt")

def extract_sentences(file_path):
    """从单个文件中提取 image_id 和拼接后的文本"""
    results = []
    image_id = None
    tokens = []

    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            if line.startswith("image_id:"):
                # 写入上一条样本
                if image_id and tokens:
                    text = "".join(tokens)
                    results.append(f"{image_id} {text}")
                # 新样本开始
                image_id = line.split(":", 1)[1].strip()
                tokens = []
            else:
                # 提取第一列 token
                parts = line.split()
                if len(parts) >= 1:
                    token = parts[0]
                    tokens.append(token)

        # 最后一条样本写入
        if image_id and tokens:
            text = "".join(tokens)
            results.append(f"{image_id} {text}")

    return results

def main():
    all_results = []
    for file_path in INPUT_FILES:
        print(f"📘 正在处理: {file_path.name}")
        sentences = extract_sentences(file_path)
        all_results.extend(sentences)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f_out:
        for line in all_results:
            f_out.write(line + "\n")

    print(f"✅ 已保存结果到: {OUTPUT_FILE.resolve()}")
    print(f"共提取 {len(all_results)} 条样本。")

if __name__ == "__main__":
    main()
